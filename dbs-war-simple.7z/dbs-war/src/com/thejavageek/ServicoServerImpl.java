package com.thejavageek;
import javax.ejb.EJB;
import javax.jws.WebService;

import br.com.delphos.billing.excecoes.BillingException;
import br.com.delphos.billing.servicos.BillingService;
import br.com.delphos.billing.servicos.retornos.RetornoIniciarVendaCartaoCredito;



@WebService(endpointInterface = "com.thejavageek.ServicoServer")
public class ServicoServerImpl implements ServicoServer {
	
	   @EJB( lookup="java:global/dbs/BillingServiceBean")
	   private BillingService billingservice;
	 
		public String sayHello(String name) {
			return billingservice.printHello();
					//"Hello " + name + " !, Hope you are doing well !!";
		}

		
		public RetornoIniciarVendaCartaoCredito iniciarVendaCartaoCredito(
				String token, String codigoEmpresa, String codigoProduto,
				String codigoSistema, String cpf, String nome, String email,
				String dddCelular, String telefoneCelular, String dddContato,
				String telefoneContato, String codigoVenda, String dataVenda,
				String bandeiraCartao, String cpfPortadorCartao,
				String nomePortadorCartao, String numeroCartao,
				String vencimentoCartao, String cvvCartao, String tipoCobranca,
				String quantidadeParcelas, String valorCobranca,
				String dataPrimeiraCobranca, String dataFimVigencia)
				throws BillingException {
			// TODO Auto-generated method stub
			return billingservice.iniciarVendaCartaoCredito(token, codigoEmpresa, codigoProduto, codigoSistema, cpf, nome, email, dddCelular, telefoneCelular, dddContato, telefoneContato, codigoVenda, dataVenda, bandeiraCartao, cpfPortadorCartao, nomePortadorCartao, numeroCartao, vencimentoCartao, cvvCartao, tipoCobranca, quantidadeParcelas, valorCobranca, dataPrimeiraCobranca, dataFimVigencia);
		}
	
}

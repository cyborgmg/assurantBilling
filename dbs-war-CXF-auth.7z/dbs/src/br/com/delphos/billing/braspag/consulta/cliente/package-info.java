/**
 * This webservice returns PAGADOR informations
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "https://www.pagador.com.br/query/pagadorquery", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.delphos.billing.braspag.consulta.cliente;

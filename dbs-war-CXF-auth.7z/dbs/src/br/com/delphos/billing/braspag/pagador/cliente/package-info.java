/**
 * This webservice authorizes PAGADOR orders
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "https://www.pagador.com.br/webservice/pagador", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.delphos.billing.braspag.pagador.cliente;

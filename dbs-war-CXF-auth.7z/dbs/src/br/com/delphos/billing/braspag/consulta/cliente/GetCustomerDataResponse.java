
package br.com.delphos.billing.braspag.consulta.cliente;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetCustomerDataResult" type="{https://www.pagador.com.br/query/pagadorquery}CustomerDataResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getCustomerDataResult"
})
@XmlRootElement(name = "GetCustomerDataResponse")
public class GetCustomerDataResponse {

    @XmlElement(name = "GetCustomerDataResult")
    protected CustomerDataResponse getCustomerDataResult;

    /**
     * Gets the value of the getCustomerDataResult property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerDataResponse }
     *     
     */
    public CustomerDataResponse getGetCustomerDataResult() {
        return getCustomerDataResult;
    }

    /**
     * Sets the value of the getCustomerDataResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerDataResponse }
     *     
     */
    public void setGetCustomerDataResult(CustomerDataResponse value) {
        this.getCustomerDataResult = value;
    }

}

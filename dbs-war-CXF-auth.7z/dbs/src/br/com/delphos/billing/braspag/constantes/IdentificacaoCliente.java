package br.com.delphos.billing.braspag.constantes;

public enum IdentificacaoCliente {

	Cpf("CPF");
	
	private final String valor;

	private IdentificacaoCliente(String valor) {
		this.valor = valor;
	}

	public String getValor() {
		return valor;
	}
}

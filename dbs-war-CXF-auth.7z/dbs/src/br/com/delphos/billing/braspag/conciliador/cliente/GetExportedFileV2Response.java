
package br.com.delphos.billing.braspag.conciliador.cliente;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetExportedFileV2Result" type="{https://reconciliation.braspag.com.br}GetExportedFileV2Response" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getExportedFileV2Result"
})
@XmlRootElement(name = "GetExportedFileV2Response")
public class GetExportedFileV2Response {

    @XmlElement(name = "GetExportedFileV2Result")
    protected GetExportedFileV2Response2 getExportedFileV2Result;

    /**
     * Gets the value of the getExportedFileV2Result property.
     * 
     * @return
     *     possible object is
     *     {@link GetExportedFileV2Response2 }
     *     
     */
    public GetExportedFileV2Response2 getGetExportedFileV2Result() {
        return getExportedFileV2Result;
    }

    /**
     * Sets the value of the getExportedFileV2Result property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetExportedFileV2Response2 }
     *     
     */
    public void setGetExportedFileV2Result(GetExportedFileV2Response2 value) {
        this.getExportedFileV2Result = value;
    }

}

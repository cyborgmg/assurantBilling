/**
 * Webservice para download de arquivos exportados pelo Reconciliation.
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "https://reconciliation.braspag.com.br", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.delphos.billing.braspag.conciliador.cliente;

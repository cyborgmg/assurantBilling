package br.com.delphos.billing.braspag.util;

public class BraspagServiceFactories {

	public static PagadorQueryFactory newPagadorQueryFactory() {
		return new PagadorQueryFactory();
	}

	public static PagadorTransactionFactory newPagadorTransactionFactory() {
		return new PagadorTransactionFactory();
	}
	
	public static PagadorReconciliationFactory newPagadorReconciliationFactory() {
		return new PagadorReconciliationFactory();
	}
}

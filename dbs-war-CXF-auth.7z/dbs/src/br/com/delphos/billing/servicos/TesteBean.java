package br.com.delphos.billing.servicos;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

/**
 * Session Bean implementation class TesteBean
 */
@Stateless(name = "TesteBean")
public class TesteBean implements Teste {

    /**
     * Default constructor. 
     */
    public TesteBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String printHello() {
		// TODO Auto-generated method stub
		return "Olá Mundo";
	}

}

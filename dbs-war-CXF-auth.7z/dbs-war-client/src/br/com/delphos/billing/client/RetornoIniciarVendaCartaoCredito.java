
package br.com.delphos.billing.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de retornoIniciarVendaCartaoCredito complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="retornoIniciarVendaCartaoCredito">
 *   &lt;complexContent>
 *     &lt;extension base="{http://servicos.billing.delphos.com.br/}retornoBillingService">
 *       &lt;sequence>
 *         &lt;element name="codigoProduto" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codigoVenda" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codigoVendaBilling" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retornoIniciarVendaCartaoCredito", propOrder = {
    "codigoProduto",
    "codigoVenda",
    "codigoVendaBilling"
})
public class RetornoIniciarVendaCartaoCredito
    extends RetornoBillingService
{

    protected String codigoProduto;
    protected String codigoVenda;
    protected String codigoVendaBilling;

    /**
     * Obt�m o valor da propriedade codigoProduto.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoProduto() {
        return codigoProduto;
    }

    /**
     * Define o valor da propriedade codigoProduto.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoProduto(String value) {
        this.codigoProduto = value;
    }

    /**
     * Obt�m o valor da propriedade codigoVenda.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoVenda() {
        return codigoVenda;
    }

    /**
     * Define o valor da propriedade codigoVenda.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoVenda(String value) {
        this.codigoVenda = value;
    }

    /**
     * Obt�m o valor da propriedade codigoVendaBilling.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoVendaBilling() {
        return codigoVendaBilling;
    }

    /**
     * Define o valor da propriedade codigoVendaBilling.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoVendaBilling(String value) {
        this.codigoVendaBilling = value;
    }

}

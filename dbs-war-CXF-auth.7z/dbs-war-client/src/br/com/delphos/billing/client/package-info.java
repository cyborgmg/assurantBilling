@javax.xml.bind.annotation.XmlSchema(namespace = "http://servicos.billing.delphos.com.br/")
package br.com.delphos.billing.client;

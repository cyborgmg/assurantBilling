package br.com.delphos.billing.configuracoes;

public class Constantes {
	
	public static final int EscalaValorMonetario = 2;
	public static final int PrecisaoValorMonetario = 14;

	public static final int EscalaValorTaxa = 6;
	public static final int PrecisaoValorTaxa = 10;
}

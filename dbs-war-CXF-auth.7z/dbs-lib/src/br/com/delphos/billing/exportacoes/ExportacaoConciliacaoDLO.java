package br.com.delphos.billing.exportacoes;

import javax.ejb.Remote;

import br.com.delphos.billing.persistencia.DLOEntidade;

@Remote
public interface ExportacaoConciliacaoDLO extends DLOEntidade<ExportacaoConciliacao> {

}

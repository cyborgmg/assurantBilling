package br.com.delphos.billing.servicos.retornos;

public class RetornoObterCodigoTransacaoProvedor extends RetornoUtilitario {
	private static final long serialVersionUID = 1L;
	
	private boolean chegouNaOperadora;
	private String codigoPedidoProvedor;
	private String codigoTransacaoProvedor;
	
	public boolean isChegouNaOperadora() {
		return chegouNaOperadora;
	}

	public void setChegouNaOperadora(boolean chegouNaOperadora) {
		this.chegouNaOperadora = chegouNaOperadora;
	}

	public String getCodigoPedidoProvedor() {
		return codigoPedidoProvedor;
	}

	public void setCodigoPedidoProvedor(String codigoPedidoProvedor) {
		this.codigoPedidoProvedor = codigoPedidoProvedor;
	}

	public String getCodigoTransacaoProvedor() {
		return codigoTransacaoProvedor;
	}
	
	public void setCodigoTransacaoProvedor(String codigoTransacaoProvedor) {
		this.codigoTransacaoProvedor = codigoTransacaoProvedor;
	}

}

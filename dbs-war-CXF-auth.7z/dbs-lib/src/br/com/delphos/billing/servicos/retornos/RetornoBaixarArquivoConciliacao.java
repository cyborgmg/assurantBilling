package br.com.delphos.billing.servicos.retornos;

import java.io.Serializable;

import br.com.delphos.billing.conciliacoes.ControleConciliacao;
import br.com.delphos.billing.util.RetornoServico;

public class RetornoBaixarArquivoConciliacao extends RetornoUtilitario implements Serializable, RetornoServico  {
	private static final long serialVersionUID = 1L;

	private ControleConciliacao controleConciliacao;

	public ControleConciliacao getControleConciliacao() {
		return controleConciliacao;
	}

	public void setControleConciliacao(ControleConciliacao controleConciliacao) {
		this.controleConciliacao = controleConciliacao;
	}
	
	
}

package br.com.delphos.billing.servicos;

import javax.ejb.Remote;

@Remote
public interface Teste {

	public String printHello();
	
}

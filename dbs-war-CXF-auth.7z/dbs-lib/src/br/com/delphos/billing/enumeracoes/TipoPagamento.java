package br.com.delphos.billing.enumeracoes;

public enum TipoPagamento {

	Vista,
	Parcelado,
	VigenciaAberta;
}

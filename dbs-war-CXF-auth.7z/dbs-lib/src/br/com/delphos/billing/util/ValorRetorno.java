package br.com.delphos.billing.util;

public interface ValorRetorno {

	String getValor();
}

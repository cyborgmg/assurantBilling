package br.com.delphos.billing.adquirentes;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-10-30T10:39:44.710-0200")
@StaticMetamodel(AdquirenteBandeiraPK.class)
public class AdquirenteBandeiraPK_ {
	public static volatile SingularAttribute<AdquirenteBandeiraPK, Long> idAdquirente;
	public static volatile SingularAttribute<AdquirenteBandeiraPK, Long> idBandeira;
	public static volatile SingularAttribute<AdquirenteBandeiraPK, Long> idContratoCobranca;
}
